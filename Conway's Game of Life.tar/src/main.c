#include <stdio.h>
#include <stdbool.h>

#include "life.h"

/* Be sure to read life.h and the other given source files to understand
 * what they provide and how they fit together.  You don't have to
 * understand all of the code, but you should understand how to call
 * parse_life() and clearterm().
 */

/* This is where your program will start.  You should make sure that it
 * is capable of accepting either one or two arguments; the first
 * argument (which is required) is a starting state in one of the Life
 * formats supported by parse_life(), and the second (which is optional)
 * is a number of generations to run before printing output and stopping.
 *
 * The autograder will always call your program with two arguments.  The
 * one-argument format (as described in the handout) is for your own
 * benefit!
 */



void get_neighbors(char grid[26][82], int y, int x, char *neighbors);
int liveNeighbors(char *neighbors);
void next_gen(char gen1[26][82], char gen2[26][82]);
void add_border(char matrice[26][82]);
int submain(char *Subargv1, char *Subargv2);

int main(int argc, char *argv[]) {
    int z;
    if (argc > 3) {
        for (z = 3; z < argc; z++) {
            if (argv[z][0] == '-') {
                argv[2][0] = '1';
                submain(argv[1], argv[2]);
            }
            else {
                printf("error1");
                return 1;
            }
        }
    }
    else if (argc == 3) {
        submain(argv[1], argv[2]);
    }
    else {
        printf("erro2\n");
        return 1;
    }
}


// creates array of neighbors of a cell
void get_neighbors(char grid[26][82], int y, int x, char neighbors[8]) {
    neighbors[0] = grid[y-1][x-1];
    neighbors[1] = grid[y-1][x];
    neighbors[2] = grid[y-1][x+1];
    neighbors[3] = grid[y][x-1];
    neighbors[4] = grid[y][x+1];
    neighbors[5] = grid[y+1][x-1];
    neighbors[6] = grid[y+1][x];
    neighbors[7] = grid[y+1][x+1];
}

// counts the live neighbors of a cell
int liveNeighbors(char neighbors[8]) {
    int i;
    int num = 0;

    for (i = 0; i < 8; i++) {
        if (neighbors[i] == 'X') {
            num = num + 1;
        }
    }
    return num;
}

// creates new matrice based on previous generation
void next_gen(char gen1[26][82], char gen2[26][82]) {
    int a, b;
    char neighbors[8];

     for (a = 1; a < 25; a++) {
        for (b = 1; b < 81; b++) {
            get_neighbors(gen1, a, b, neighbors);
            int livenum = liveNeighbors(neighbors);
            if (gen1[a][b] == 'X') {
                if (livenum < 2) {
                    gen2[a][b] = ' ';
                }
                if (livenum > 3) {
                    gen2[a][b] = ' ';
                }
                if (livenum == 2){
                    gen2[a][b] = 'X';
                }
                if (livenum == 3){
                    gen2[a][b] = 'X';
                }
            }
            if (gen1[a][b] == ' ') {
                if (livenum == 3) {
                    gen2[a][b] = 'X';
                }
                else {
                    gen2[a][b] = ' ';
                }
            }
        }
    }
}



void add_border(char matrice[26][82]) {
    int a, b;

    for (a = 0; a < 26; a++) {
        if (a == 0 ||a == 25) {
            for (b = 0; b < 82; b++) {
                matrice[a][b] = ' ';
            }
        }
        else {
            matrice[a][0] = ' ';
            matrice[a][81] = ' ';
        }
    }
}


int submain(char *Subargv1, char *Subargv2) {
    int i, j;
    char matrice[2][26][82];

    
    // this creates a new matrice from the initial input
    for (i = 0; i < 24; i++) {
        for (j = 0; j < 80; j++) {
            matrice[0][i+1][j+1] = parse_life(Subargv1)[i][j];
            //printf("%c", matrice[0][i+1][j+1]);
        }
        //printf("\n");
        //printing by line gives error, printing by character doesnt
    }

    
    //this add border of dead cells
    add_border(matrice[0]);

   

    // this alternates matrices and updates the matrice with the next gen
    int h;
    int lastgen = 0;
    for (h = 0; Subargv2[h] != '\0'; h++) {
        lastgen = (lastgen * 10) + (Subargv2[h] - '0');
    }
    int previous = 0;
    int current = 0;

    lastgen = lastgen - 1;
    for (previous = 0; lastgen >= 0; previous = (previous + 1) % 2) {
        if (previous == 0) {
            current = 1;
            next_gen(matrice[previous], matrice[current]);
            lastgen = lastgen - 1;
        }
        if (previous == 1) {
            current = (previous + 1) % 2;
            next_gen(matrice[previous], matrice[current]);
            lastgen = lastgen - 1;
        }
        
    }



    
    int n, m;
    for (n = 1; n < 25; n++) {
        for (m = 1; m < 81; m++) {
            printf("%c", matrice[current][n][m]);
        }
        printf("\n");
    }
    
    return 0;
}
